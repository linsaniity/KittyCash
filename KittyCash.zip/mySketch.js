// README
/*
<Kitty Cash>
 Sandy Lin - 20905461
 s294lin
 
 INSTRUCTIONS
 <Kitty cash is a game where you play as a kitty cat, who is robbing a bank. Press the
 play button to start the game. You control the character by using the arrow keys
 (up, down, left right to move the character in that direction).
 and the objective is to get as many money bags as you can without losing all your
 lives(you start with three lives and lose one each time you touch the police car). 
 The screen warps from right to left, the police car is constantly moving and loads at 
 a random y position each time. When you lose all your lives, press the play button on the 
 game over screen to restart. If game is in progress and you wish to return to the home screen,
 press key 'q'>
 
 */

// all code goes below here ....

let gameStart = false;

let linesNum;
let linesX;
let lineSpacing = 25;

//cat location
let x = 200;
let y = 300;
let xSpeed = 0;
let ySpeed = 0;
let catSize = 60;

let speed = 1;
let gravity = 0.2;

let leftPressed = false;
let downPressed = false;
let rightPressed = false;
let upPressed = false;

//Target position
let xTarget = 300;
let yTarget = 700;

//police position
let pTargetx = 100;
let pTargety = 160;
let carSize = 80;

//player lives
let lives = 3;
let heart = [];

let score = 0;

//image variables
let img;
let go;
let heartImg;

function preload() {
  img = loadImage("KittySnatcher.jpg");
  go = loadImage("GameOver.jpg");
  heartImg = loadImage("heart.png");
}

function setup() {
  createCanvas(400, 800);
  startScreen();
}

function draw() {

  if (gameStart === false && lives === 3 || lives === 2 || lives === 1) {
    startScreen();
  }
  if (gameStart === true) {
    if (score < 10) {
      background("#1D687E"); 
      //LOOPS
      linesX = 0;
      for (let i = 0; i < width; i++) {
        stroke("#353958");
        strokeWeight(1);
        line(linesX, 0, linesX, height);
        linesX += lineSpacing;
      }
      //scoreboard
      stroke("#AE85B7");
      fill('#24809B');
      ellipse(width/ 2, height / 2, 250);
      textSize(80);
      strokeWeight(4);
      text(score, 180, 415);
    }
    if (score >= 10) {
      background("#1D277C"); 
      linesX = 0;
      for (let i = 0; i < width; i++) {
        stroke("#353958");
        strokeWeight(1);
        line(linesX, 0, linesX, height);
        linesX += lineSpacing;
      }
      //scoreboard
      stroke("#AE85B7");
      fill('#4953A5');
      ellipse(width/ 2, height / 2, 250);
      textSize(80);
      strokeWeight(4);
      text(score, 160, 415);
    }

    drawCat();
    drawMoneyBag(xTarget, yTarget, 40);
    drawPoliceCar();
    policeCollisionTest();
    pTargetx += 2;
    loadHearts();
    moveCat();
    collisionTest();

    if (y + 80 > 800 || y + 80 === 800) {
      speed = -0.98 * speed;
    } else if (y < 0 || y === 0) {
      speed = 0.98 * speed;
    }
    if (pTargetx > width) {
      pTargetx = 0;
      pTargetx += 5;
      pTargety = random(50, 750);
    }
  }
}

function mousePressed() {
  //play button
  if (circleHitTest(mouseX, mouseY, width/2, 500, 50)) {
    gameStart = true;
    lives = 3;
    score = 0;
  } else {
    gameStart = false;
    lives = 3;
  }
}

//KEYBOARD EVENT FUNCTION
function keyPressed() {
  if (key === 'q' || key === 'Q') {//go back to home
    gameStart = false;
  }   
  if (keyCode === LEFT_ARROW) {
    leftPressed = true;
  } 
  if (keyCode === DOWN_ARROW) {
    downPressed = true;
  }
  if (keyCode === RIGHT_ARROW) {
    rightPressed = true;
  } 
  if (keyCode === UP_ARROW) {
    upPressed = true;
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW) {
    leftPressed = false;
  } 
  if (keyCode === DOWN_ARROW) {
    downPressed = false;
  }
  if (keyCode === RIGHT_ARROW) {
    rightPressed = false;
  } 
  if (keyCode === UP_ARROW) {
    upPressed = false;
  }
}

function circleHitTest(pX, pY, cX, cY, r) {
  let f = dist(pX, pY, cX, cY);
  if (f <= r) {
    return true;
  } else {
    return false;
  }
}
//LOADING AND DISPLAYING IMAGES
function startScreen() {
  image(img, 0, 0);

  //play button
  v = map(mouseX, 0, width, 0, 255);
  fill(v, 0, 350);
  noStroke();
  ellipse(width/ 2, 500, 100);

  fill(255);
  triangle(185, 480, 185, 520, 225, 500);
}

//DRAWING ATTRIBUTES
function drawCat() {
  //draws cat
  fill(255);
  strokeWeight(1);
  ellipse(x + 25, y + 80, 5, 25);//tail
  ellipse(x + 35, y + 90, 20, 5);

  fill("#E5B3F0");
  stroke("#AE85B7");
  rect(x, y, 60, 80, 10);//body
  triangle(x, y + 5, x + 10, y - 20, x + 20, y);//left ear
  triangle(x + 40, y, x + 50, y - 20, x + 60, y + 5);//right ear

  fill(255);
  triangle(x + 5, y, x + 10, y - 15, x + 15, y);
  triangle(x + 45, y, x + 50, y - 15, x + 55, y);

  fill(255, 255, 255);
  ellipse(x + 30, y + 40, 40, 65);

  //mask
  fill("#3D3B3E");
  stroke(0);
  rect(x, y, 60, 55, 10);
  fill("#838383");
  line(x + 5, y + 2, x + 5, y + 52);
  line(x + 10, y, x + 10, y + 55);
  line(x + 15, y, x + 15, y + 55);
  line(x + 20, y, x + 20, y + 55);
  line(x + 25, y, x + 25, y + 55);
  line(x + 30, y, x + 30, y + 55);
  line(x + 35, y, x + 35, y + 55);
  line(x + 40, y, x + 40, y + 55);
  line(x + 45, y, x + 45, y + 55);
  line(x + 50, y, x + 50, y + 55);
  line(x + 55, y + 2, x + 55, y + 52);


  //mask holes
  fill("#E5B3F0");
  stroke("#AE85B7");
  ellipse(x + 15, y + 20, 20);
  ellipse(x + 45, y + 20, 20);
  ellipse(x + 30, y + 40, 20, 10);

  //face - eyes
  fill("#275F95");
  stroke(0);
  ellipse(x + 15, y + 20, 15);
  ellipse(x + 45, y + 20, 15);

  fill(0);
  stroke("#FFDE1F");//yellow
  ellipse(x + 15, y + 20, 7);
  ellipse(x + 45, y + 20, 7);

  fill(255);//eye sparkles
  ellipse(x + 18, y + 18, 4);
  ellipse(x + 48, y + 18, 4);
  ellipse(x + 13, y + 23, 2);
  ellipse(x + 43, y + 23, 2);

  //face - mouth
  stroke(0);
  line(x + 24, y + 42, x + 30, y + 40);
  line(x + 36, y + 42, x + 30, y + 40);
  line(x + 30, y + 35, x + 30, y + 40);
  line(x + 24, y + 42, x + 22, y + 40);
  line(x + 36, y + 42, x + 38, y + 40);

  fill("#F782BD");
  stroke("#893E63");
  triangle(x + 30, y + 35, x + 25, y + 30, x + 35, y + 30);

  //whiskers
  stroke(255);
  line(x + 8, y + 40, x + 15, y + 40);
  line(x + 45, y + 40, x + 52, y + 40);
  line(x + 8, y + 35, x + 15, y + 38);
  line(x + 8, y + 45, x + 15, y + 42);
  line(x + 45, y + 38, x + 52, y + 35);
  line(x + 45, y + 42, x + 52, y + 45);

  //paws
  fill("#E5B3F0");
  stroke("#AE85B7");
  ellipse(x + 15, y + 80, 15, 10);
  ellipse(x + 45, y + 80, 15, 10);
  ellipse(x, y + 60, 10, 15);
  ellipse(x + 60, y + 60, 10, 15);
}

function gameOver() {
  if (lives === 0) { 
    background(0);
    image(go, 0, 0);

    v = map(mouseX, 0, width, 0, 255);
    fill(v, 0, 350);
    noStroke();
    ellipse(width/ 2, 500, 100);

    fill(255);
    triangle(185, 480, 185, 520, 225, 500);
    gameStart = false;
  }
}

//CONDITIONALS
function moveCat() {
  y = y + speed;
  speed = speed + gravity;

  xSpeed *= 0.96;
  ySpeed *= 0.96;
  x += xSpeed;
  y += ySpeed;
  if (rightPressed) {
    xSpeed += 0.3;
  }
  if (downPressed) {
    ySpeed += 0.3;
  }
  if (leftPressed) {
    xSpeed += -0.3;
  }
  if (upPressed) {
    ySpeed += - 0.3;
  }
  //wrap screen right to left 
  if (x + 60 > width) {
    //xSpeed *= -1;
    x = -50;
  } else if (x <= -catSize) {
    xSpeed *= -1;
  }
  if (y + 80 > height || y < 0) {
    ySpeed *= -1;
  }
}

function collisionTest() {//for points
  if (dist(x + 10, y + 30, xTarget, yTarget) < 40) {
    score++;
    xTarget = random(15, 370);
    yTarget = random(45, 780);
  } else {
    score = score;
  }
}

//USER DEFINED FUNCTION
function drawMoneyBag(n, m, mSize) {
  fill('#E3DAAE');
  stroke('#796F3E');
  ellipse(n, m, mSize);
  triangle(n, m - 20, n - 15, m - 30, n + 15, m - 30);

  stroke('#59B75C');
  strokeWeight(2);
  fill('#59B75C');
  textSize(20);
  text('$', n - 5, m + 5);
}

function drawPoliceCar() {
  //police car
  fill(0);
  strokeWeight(2);
  stroke(0);
  rect(pTargetx, pTargety, carSize, 30);
  fill(255);
  rect(pTargetx + 20, pTargety, 40, 30);

  //lights
  fill(255, 0, 0);
  noStroke();
  rect(pTargetx + 30, pTargety - 20, 10, 10);
  fill(0, 0, 255);
  rect(pTargetx + 40, pTargety - 20, 10, 10);

  fill("#7AD7F2");
  quad(pTargetx + 20, pTargety, pTargetx + 30, 
    pTargety - 15, pTargetx + 50, pTargety - 15, pTargetx + 60, pTargety);

  fill("#292929");
  ellipse(pTargetx + 20, pTargety + 30, 20);
  ellipse(pTargetx + 60, pTargety + 30, 20);
}

//RECTANGLE HIT TEST
function policeCollisionTest() {
  if (x + catSize >= pTargetx && x + catSize <= pTargetx + carSize && y <= pTargety + 80 && y >= pTargety - 20) {
    lives = lives - 1;
    pTargetx = 0;
    pTargetx += 5;
    pTargety = random(50, 735);
  } else {
    lives = lives;
  }
}


function loadHearts() {
  //ARRAYS
  hearts = [50, 150, 250];
  if (lives === 3) {
    heartImg.resize(70, 0);
    image(heartImg, hearts[0], 25);
    image(heartImg, hearts[1], 25);
    image(heartImg, hearts[2], 25);
  }
  if (lives === 2) {
    image(heartImg, hearts[0], 25);
    image(heartImg, hearts[1], 25);
  }
  if (lives === 1) {
    image(heartImg, hearts[0], 25);
  }
  if (lives === 0) {
    gameOver();
  }
}